<!DOCTYPE html>
<!-- Dichiarazione del tipo di documento HTML -->
<html lang="en">
<!-- Inizio del documento HTML con l'attributo lang impostato su "en" per indicare che la lingua principale è l'inglese -->
  <head>
  <!-- Inizio dell'elemento head, che contiene metadati sulla pagina web -->
    <meta charset="UTF-8">
    <!-- Dichiarazione del set di caratteri utilizzato, in questo caso UTF-8 -->
    <title>Password generatore</title>
    <!-- Titolo della pagina web, che appare nella scheda del browser -->
    <link rel="stylesheet" href="style.css">
    <!-- Collegamento a un foglio di stile esterno chiamato "style.css" -->
  </head>
  <!-- Fine dell'elemento head -->
  <body>
  <!-- Inizio dell'elemento body, che contiene il contenuto principale della pagina web -->
    <div class="container">
    <!-- Inizio di un div con la classe "container", che può essere utilizzata per applicare stili specifici -->
      <h1>Password Generator</h1>
      <!-- Titolo di livello 1 -->
      <form method="post">
      <!-- Inizio di un form che invia i dati tramite il metodo POST -->
        <button type="submit" name="generate">Generate Password</button>
        <!-- Bottone che invia il form. Quando viene premuto, il form invia i dati e la pagina si ricarica -->
      </form>
      <!-- Fine del form -->
    </div>
    <!-- Fine del div -->
  </body>
  <!-- Fine dell'elemento body -->
  <footer>
  <!-- Inizio dell'elemento footer, che contiene informazioni aggiuntive come note a piè di pagina e link correlati -->
    <div class="result">
    <!-- Inizio di un div con la classe "result", che può essere utilizzata per applicare stili specifici -->
    <?php include 'generator.php';?>
    <!-- Include il file "generator.php", che contiene il codice PHP per generare la password -->
    </div>
    <!-- Fine del div -->
  </footer>
  <!-- Fine dell'elemento footer -->
</html>
<!-- Fine del documento HTML -->