<?php

            if(isset($_POST['generate'])) {
                // Controlla se è stato inviato un form con il nome 'generate'

                $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                // Definisce una stringa di caratteri che può essere utilizzata per generare una password

                $password = substr(str_shuffle($chars), 0, 15);
                // Mescola casualmente i caratteri nella stringa $chars e ne prende i primi 15 per creare una password

                echo "<p>La tua Password generata:
                <p></p>
                <strong>$password</strong></p>";
                // Stampa un paragrafo con la password generata
            }
 
?>
